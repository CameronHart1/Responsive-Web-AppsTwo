<template>
<!-- pretty barebones, relevent data will be added later -->
<div style="text-align:center;">
    <h1> About us I guess? </h1>
    <p> lots of really interesting stuff super informative</p>
</div>
</template>
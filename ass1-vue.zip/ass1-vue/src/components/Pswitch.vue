<template>
<!-- might just move this to the ProfileHome.vue
this is the component that controls the big slider -->
         <div>
        <label class="switch">
            <input type="checkbox" name="HomePageSwitch" value="Garden" id="LandingSwitch">
            <span class="slider"></span>
            <span class="text"></span>
        </label>
    </div>
</template>

<style scoped>
@import '../assets/styles/Pslider.css';
</style>
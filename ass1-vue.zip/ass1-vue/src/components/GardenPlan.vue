<template>
  <div id="PlanBod">
      <!-- this draws that ugly gray graphic, later it will be replaced with a png of a snapshot of the active garden plan
      however garden planner is yet to be implemented -->
    <h2 style="text-align: center">Garden Plan</h2>
    <div style="border-radius: 2px; border: 3px solid #ceb7de40; padding-left: 150px">
      <div style="width: 300px; height: 300px; background-color: #00000080">
        <div
          style="width: 200px; height: 100px; background-color: #00000080"
        ></div>
        <div
          style="
            margin-top: 50px;
            width: 200px;
            height: 100px;
            background-color: #00000080;
          "
        ></div>
      </div>
    </div>
  </div>
</template>